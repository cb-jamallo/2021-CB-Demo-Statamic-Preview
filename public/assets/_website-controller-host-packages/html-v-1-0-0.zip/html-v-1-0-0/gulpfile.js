const  gulp = require('gulp');
const { task, watch, series, parallel } = require('gulp');

const  postcss = require('gulp-postcss');
const  autoprefixer = require('autoprefixer');
const  cssnano = require('gulp-cssnano');


function clean(cb)
{  
    // Do something...
    cb();
}

function stylesheet(cb)
{
    return gulp.src(['./src/lib/css/global.css'])
            .pipe(cssnano())
            .pipe(gulp.dest('./build/lib/css'));
    // body omitted
    cb();
}

function javascript(cb)
{
    // body omitted
    cb();
}


exports.stylesheet = stylesheet;
exports.javascript = javascript;
exports.default = series(clean, parallel(stylesheet, javascript));